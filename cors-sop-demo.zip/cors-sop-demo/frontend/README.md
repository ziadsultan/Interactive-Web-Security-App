# CORS & Preflight Debugger

A modern, interactive tool for learning and debugging Cross-Origin Resource Sharing (CORS) and the Same-Origin Policy (SOP) in web development.

---

## Overview

This project is a full-stack demo that lets you:
- **Visualize and test CORS and preflight requests** between a React frontend and an Express backend.
- **Toggle CORS on/off** in real time and see how it affects API calls and browser security.
- **Experiment with preflight (OPTIONS) and POST requests** to understand what browsers and servers do under the hood.
- **Get instant, scenario-specific explanations** for every CORS/preflight/API call result.

---

## Features

- **CORS Toggle:** Instantly enable or disable CORS on the backend with a single button. Toggling CORS resets the UI and hides any previous results or explanations.
- **Preflight Button:** Simulate a browser preflight (OPTIONS) request and see allowed methods/headers.
- **API Call Button:** Send a POST request with custom headers and see the result or error.
- **Explain Button:** Pops up a detailed, context-aware explanation for the current result—tailored to CORS enabled/disabled, preflight, or API call scenarios.
- **Live Feedback:** The UI updates to show whether CORS is enabled, and disables/enables actions accordingly.
- **Beautiful, Responsive UI:** Modern design, vibrant colors, and a funky font for a fun learning experience.
- **Formatted Results:** API responses are shown in a clean, readable table with modern, consistent styling.
- **Consistent Output & Explanation Boxes:** Both use the same card-like style, with scrollbars and clear formatting.

---

## Screenshots

### Main UI
![Main UI](./mainUI.png)

| Feature | Enabled State | Disabled State |
|---------|--------------|---------------|
| **API Call** | ![API Enabled](./docs/screenshots/API_Call_Enabled.png) | ![API Disabled](./docs/screenshots/API_Call_Disabled.png) |
| **Preflight** | ![Preflight Enabled](../Preflight_En.png) | ![Preflight Disabled](./docs/screenshots/Preflight_Disabled.png) |
| **Explain Popup** | ![Explain Popup](./docs/screenshots/Explain_Popup.png) | |

---

## How It Works

- The **frontend** (React + Vite) runs on `localhost:5173`.
- The **backend** (Express) runs on `localhost:4000`.
- The frontend communicates with the backend using fetch requests.
- The backend exposes endpoints for:
  - `/api/data` (GET, POST, OPTIONS)
  - `/api/cors-state` (get current CORS state)
  - `/api/cors-toggle` (enable/disable CORS)
- When CORS is disabled, the backend blocks all `/api/data` requests and omits CORS headers, simulating a real-world CORS failure.
- The UI updates in real time to reflect the backend's CORS state.
- Toggling CORS resets the UI and hides any previous results or explanations.

---

## Setup & Running Locally

1. **Clone the repository:**
   ```bash
   git clone <your-repo-url>
   cd cors-sop-demo
   ```

2. **Install dependencies:**
   ```bash
   cd backend
   npm install
   cd ../frontend
   npm install
   ```

3. **Start the backend:**
   ```bash
   cd ../backend
   node server.js
   ```

4. **Start the frontend:**
   ```bash
   cd ../frontend
   npm run dev
   ```

5. **Open your browser:**
   - Go to [http://localhost:5173](http://localhost:5173)

---

## Usage Guide

- **Enable/Disable CORS:**
  - Use the toggle button at the top to turn CORS on or off.
  - When CORS is disabled, API calls will be blocked and the UI will show an error.
  - Toggling CORS resets the UI and hides any previous results or explanations.

- **Preflight:**
  - Click the Preflight button to send an OPTIONS request and see what methods/headers are allowed.
  - If CORS is disabled, you'll see a clear error message.

- **Call Backend API:**
  - Click to send a POST request with custom headers.
  - See the backend's response or a CORS error, depending on the toggle state.

- **Explain:**
  - Click the Explain button below the output box to see a detailed, scenario-specific explanation of what happened and why.
  - The explanation changes based on whether CORS is enabled/disabled, and whether the result is from a preflight or API call.
  - Hiding the explanation or toggling CORS resets the explanation popup.

- **Formatted Output:**
  - All responses are shown in a clean table for easy reading, with modern, consistent styling.

---

## How the CORS Toggle Works

- The backend keeps an in-memory flag for CORS.
- Toggling the button sends a request to `/api/cors-toggle` to enable/disable CORS.
- When disabled, the backend blocks all `/api/data` requests and omits CORS headers, simulating a real CORS failure.
- The frontend always stays in sync with the backend's CORS state.
- Toggling CORS resets the UI and hides any previous results or explanations.

---

## Customization

- You can easily change the allowed origins, methods, or headers in `backend/server.js`.
- The UI is fully responsive and can be themed by editing the styles in `frontend/src/App.jsx`.

