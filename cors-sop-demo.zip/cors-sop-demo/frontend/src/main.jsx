import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom'
import CSRFApp from './CSRFApp.jsx';

function Landing() {
  const navigate = useNavigate();
  return (
    <div style={{
      minHeight: '100vh',
      width: '99vw',
      background: 'linear-gradient(135deg, #0f0f0f 0%, #1a1a1a 25%, #2a2a2a 50%, #404040 75%, #ffffff 100%)',
      fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
      padding: 0,
      margin: 0,
      boxSizing: 'border-box',
      overflowY: 'auto',
    }}>
      <div style={{
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        padding: '120px 20px 80px 20px',
        maxWidth: 1200,
        margin: '0 auto',
      }}>
        <h1 style={{ fontSize: '5rem', color: '#fff', marginBottom: 15, letterSpacing: 1, textShadow: '0 2px 12px #0008', textAlign: 'center' }}>
          Interactive Web Security Lab
        </h1>
        <div style={{ color: '#bdbdbd', fontSize: '1.4rem', maxWidth: 800, textAlign: 'center', marginBottom: 80, lineHeight: 1.5 }}>
          Explore and interact with hands-on demos for modern web security concepts. Choose a lab below to get started!
        </div>
        
        {/* CORS Demo Section */}
        <div style={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center', 
          marginBottom: 80,
          width: '100%',
          maxWidth: 500
        }}>
                    <div style={{ 
            position: 'relative',
            color: '#e0e0e0', 
            fontSize: '1.1rem', 
            textAlign: 'center', 
            marginBottom: 80,
            lineHeight: 1.6,
            maxWidth: 400,
            padding: '20px',
            borderRadius: '12px',
          }}>
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              borderRadius: '12px',
              boxShadow: '0 0 80px 0 #38bdf899',
              zIndex: 0,
            }}></div>
            <div style={{ position: 'relative', zIndex: 1 }}>
              <strong style={{ color: '#38bdf8', fontSize: '1.2rem' }}>CORS (Cross-Origin Resource Sharing)</strong><br/>
              Learn how browsers handle cross-origin requests and how CORS policies protect against unauthorized access. 
              Toggle CORS protection on/off and see how it affects API calls from different origins.
              <br/><br/>
              <button
                className="gradient-btn"
                style={{
                  width: 220,
                  height: 60,
                  fontSize: '1.18rem',
                  borderRadius: 999,
                  fontWeight: 800,
                  letterSpacing: 1,
                  background: '#18181b',
                  color: '#fff',
                  border: '2.5px solid #264653',
                  cursor: 'pointer',
                  transition: 'box-shadow 0.2s',
                }}
                onClick={() => navigate('/cors')}
              >
                CORS Demo
              </button>
            </div>
          </div>
        </div>

        {/* CSRF Demo Section */}
        <div style={{ 
          display: 'flex', 
          flexDirection: 'column', 
          alignItems: 'center',
          width: '100%',
          maxWidth: 500
        }}>
          <div style={{ 
            position: 'relative',
            color: '#e0e0e0', 
            fontSize: '1.1rem', 
            textAlign: 'center', 
            marginBottom: 80,
            lineHeight: 1.6,
            maxWidth: 400,
            padding: '20px',
            borderRadius: '12px',
          }}>
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              borderRadius: '12px',
              boxShadow: '0 0 80px 0 #fde04799',
              zIndex: 0,
            }}></div>
            <div style={{ position: 'relative', zIndex: 1 }}>
              <strong style={{ color: '#fde047', fontSize: '1.2rem' }}>CSRF (Cross-Site Request Forgery)</strong><br/>
              Experience how malicious websites can trick authenticated users into performing unwanted actions. 
              See how CSRF tokens protect against these attacks and what happens when protection is disabled.
              <br/><br/>
              <button
                className="gradient-btn"
                style={{
                  width: 220,
                  height: 60,
                  fontSize: '1.18rem',
                  borderRadius: 999,
                  fontWeight: 800,
                  letterSpacing: 1,
                  background: '#18181b',
                  color: '#fff',
                  border: '2.5px solid #fde047',
                  cursor: 'pointer',
                  transition: 'box-shadow 0.2s',
                }}
                onClick={() => navigate('/csrf')}
              >
                CSRF Demo
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function CSRFPlaceholder() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: 'linear-gradient(135deg,#232526 0%,#414345 100%)', color: '#fff', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif' }}>
      <h2 style={{ fontSize: '2rem', marginBottom: 16 }}>CSRF Demo (Coming Soon)</h2>
      <div style={{ color: '#bdbdbd', fontSize: '1.1rem', maxWidth: 500, textAlign: 'center' }}>
        This section will feature an interactive Cross-Site Request Forgery (CSRF) demo. Stay tuned!
      </div>
    </div>
  );
}

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/cors" element={<App />} />
        <Route path="/csrf" element={<CSRFApp />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>
)
