import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

const CSRFApp = () => {
  const [csrfToken, setCsrfToken] = useState(() => {
    // Load token from localStorage on component mount
    const stored = localStorage.getItem('csrfToken');
    const storedExpiry = localStorage.getItem('csrfTokenExpiry');
    const storedTTL = localStorage.getItem('csrfTokenTTL');
    
    if (stored && storedExpiry && Date.now() < parseInt(storedExpiry)) {
      // Token exists and hasn't expired
      return stored;
    } else {
      // Clear expired token
      localStorage.removeItem('csrfToken');
      localStorage.removeItem('csrfTokenExpiry');
      localStorage.removeItem('csrfTokenTTL');
      return '';
    }
  });
  const [tokenExpiry, setTokenExpiry] = useState(() => {
    const stored = localStorage.getItem('csrfTokenExpiry');
    return stored ? parseInt(stored) : null;
  });
  const [tokenTTL, setTokenTTL] = useState(() => {
    const stored = localStorage.getItem('csrfTokenTTL');
    return stored ? parseInt(stored) : 0;
  });
  const [message, setMessage] = useState('');
  const [csrfEnabled, setCsrfEnabled] = useState(true);
  const [balance, setBalance] = useState(1000);
  const [loggedIn, setLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [currentUser, setCurrentUser] = useState('');
  const [showExplanation, setShowExplanation] = useState(false);
  const [tabId, setTabId] = useState('');
  const [maliciousSiteToken, setMaliciousSiteToken] = useState(''); // Separate token for malicious site
  const [lastAction, setLastAction] = useState(''); // Track the last action performed
  const [lastActionResult, setLastActionResult] = useState(''); // Track the result of the last action
  const navigate = useNavigate();

  // Fetch initial CSRF state from backend
  const fetchCsrfState = async () => {
    try {
      const response = await fetch('http://localhost:4000/api/csrf-state', {
        method: 'GET',
        credentials: 'include'
      });
      
      if (response.ok) {
        const data = await response.json();
        setCsrfEnabled(data.csrfEnabled);
      }
    } catch (error) {
      console.log('Backend not available, using default CSRF state');
    }
  };

  // Generate unique tab ID on component mount
  useEffect(() => {
    const newTabId = Math.random().toString(36).substring(2, 15) + Date.now();
    setTabId(newTabId);
    
    // Fetch initial CSRF state
    fetchCsrfState();
  }, []);

  // Timer for token TTL countdown
  useEffect(() => {
    if (tokenTTL > 0) {
      const timer = setInterval(() => {
        setTokenTTL(prev => {
          if (prev <= 1) {
            setCsrfToken('');
            setTokenExpiry(null);
            
            // Clear from localStorage
            localStorage.removeItem('csrfToken');
            localStorage.removeItem('csrfTokenExpiry');
            localStorage.removeItem('csrfTokenTTL');
            
            setMessage('CSRF Token expired! Please generate a new one.');
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(timer);
    }
  }, [tokenTTL]);

  const getExplanation = () => {
    if (!loggedIn) {
      return {
        title: "Welcome to CSRF Demo!",
        content: "This demo shows how Cross-Site Request Forgery (CSRF) attacks work and how to protect against them. Login with ziad/1021 or abdelaal/1234 to get started!"
      };
    }

    // Base state information
    const baseInfo = `Current State: ${csrfEnabled ? 'CSRF Protection ENABLED' : 'CSRF Protection DISABLED'} | Logged in as: ${currentUser} | Balance: $${balance}`;
    
    // Token status
    const tokenStatus = csrfToken 
      ? `✅ Valid CSRF Token: ${csrfToken.substring(0, 8)}... (TTL: ${formatTime(tokenTTL)})`
      : '❌ No CSRF Token Available';

    // Last action analysis
    let actionExplanation = '';
    if (lastAction) {
      switch (lastAction) {
        case 'login':
          actionExplanation = `🔐 Login Action: Successfully authenticated as ${currentUser}. Session cookies are now set and will be automatically sent with future requests.`;
          break;
          
        case 'get_token':
          if (lastActionResult === 'success') {
            actionExplanation = `🎫 Token Generation: CSRF token created successfully! This token is stored in localStorage and will be sent with legitimate transfer requests. The malicious site cannot access this token.`;
          } else {
            actionExplanation = `❌ Token Generation Failed: Could not generate CSRF token. This might be due to authentication issues or server problems.`;
          }
          break;
          
        case 'transfer_legitimate':
          if (lastActionResult === 'success') {
            actionExplanation = `✅ Legitimate Transfer: Transfer successful! $100 deducted from your account. ${csrfEnabled ? 'The CSRF token was validated and consumed (one-time use).' : 'No CSRF protection was required.'}`;
          } else if (lastActionResult === 'no_token') {
            actionExplanation = `❌ Transfer Blocked: CSRF protection is enabled but no token was provided. You must generate a CSRF token first using the "Get CSRF Token" button.`;
          } else if (lastActionResult === 'insufficient_funds') {
            actionExplanation = `❌ Transfer Failed: Insufficient funds. You need at least $100 to make a transfer.`;
          }
          break;
          
        case 'transfer_malicious':
          if (lastActionResult === 'blocked') {
            actionExplanation = `🛡️ Attack Blocked: The malicious "SHOW RECIPE" button was blocked! Even though you're logged in, the malicious site cannot access your CSRF token because it's stored in the bank's domain. This is how CSRF protection works.`;
          } else if (lastActionResult === 'success') {
            actionExplanation = `💥 Attack Successful: The malicious site successfully transferred $100 from your account! This happened because CSRF protection is disabled, making the bank vulnerable to cross-site attacks. The malicious site exploited the fact that no CSRF token validation was required.`;
          } else if (lastActionResult === 'insufficient_funds') {
            actionExplanation = `❌ Attack Failed: The malicious site tried to transfer money but you have insufficient funds.`;
          }
          break;
          
        case 'toggle_csrf':
          actionExplanation = `🔄 CSRF Protection Toggled: Protection is now ${csrfEnabled ? 'ENABLED' : 'DISABLED'}. All states have been reset - you're logged out and any existing tokens are cleared.`;
          break;
      }
    }

    // Security explanation based on current state
    let securityExplanation = '';
    if (csrfEnabled) {
      if (csrfToken) {
        securityExplanation = `🔒 Security Status: You're protected! CSRF protection is active and you have a valid token. Legitimate transfers will work, but malicious sites cannot access your token.`;
      } else {
        securityExplanation = `⚠️ Security Status: CSRF protection is active but you need a token. Generate one to make legitimate transfers. Malicious sites still cannot access tokens.`;
      }
    } else {
      securityExplanation = `🚨 Security Status: CSRF protection is DISABLED! This is dangerous - both legitimate and malicious transfers will work. This simulates a vulnerable website.`;
    }

    // Combine all explanations
    const content = `${baseInfo}\n\n${tokenStatus}\n\n${actionExplanation}\n\n${securityExplanation}`;

    return {
      title: lastAction ? `CSRF Demo - ${lastAction.replace('_', ' ').toUpperCase()}` : "CSRF Demo - Current State",
      content: content
    };
  };

  const login = async () => {
    if (username.trim() && password.trim()) {
      try {
        const response = await fetch('http://localhost:4000/login', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ username, password, tabId })
        });

        const data = await response.json();

        if (response.ok) {
          setLoggedIn(true);
          setCurrentUser(data.message.split('Welcome ')[1].split('.')[0]);
          setBalance(data.balance);
          setUsername('');
          setPassword('');
          setMessage(data.message);
          setLastAction('login');
          setLastActionResult('success');
        } else {
          setMessage(data.error || 'Login failed');
          setLastAction('login');
          setLastActionResult('failed');
        }
      } catch (error) {
        // Fallback to mock login if backend is not available
        const validUsers = {
          'ziad': { password: '1021', balance: 1400, name: 'Ziad' },
          'abdelaal': { password: '1234', balance: 1700, name: 'Abdelaal' }
        };
        
        const user = validUsers[username.toLowerCase()];
        if (user && user.password === password) {
          setLoggedIn(true);
          setCurrentUser(user.name);
          setBalance(user.balance);
          setUsername('');
          setPassword('');
          setMessage(`Login successful! Welcome ${user.name}.`);
          setLastAction('login');
          setLastActionResult('success');
        } else {
          setMessage('Invalid username or password.');
          setLastAction('login');
          setLastActionResult('failed');
        }
      }
    } else {
      setMessage('Please enter both username and password.');
    }
  };

  const fetchCsrf = async () => {
    try {
      const response = await fetch('http://localhost:4000/csrf-token', {
        method: 'GET',
        credentials: 'include'
      });

      const data = await response.json();

      if (response.ok) {
        setCsrfToken(data.csrfToken);
        setTokenExpiry(data.expiresAt);
        setTokenTTL(data.ttl);
        
        // Save to localStorage
        localStorage.setItem('csrfToken', data.csrfToken);
        localStorage.setItem('csrfTokenExpiry', data.expiresAt.toString());
        localStorage.setItem('csrfTokenTTL', data.ttl.toString());
        
        setMessage('CSRF Token generated successfully! Valid for 5 minutes.');
        setLastAction('get_token');
        setLastActionResult('success');
      } else {
        // Don't show "Not authenticated" errors to user - use fallback logic
        throw new Error('Backend error - using fallback');
      }
    } catch (error) {
      // Fallback to mock token generation if backend is not available
      const mockToken = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      const expiresAt = Date.now() + (5 * 60 * 1000); // 5 minutes
      setCsrfToken(mockToken);
      setTokenExpiry(expiresAt);
      setTokenTTL(300); // 5 minutes in seconds
      
      // Save to localStorage
      localStorage.setItem('csrfToken', mockToken);
      localStorage.setItem('csrfTokenExpiry', expiresAt.toString());
      localStorage.setItem('csrfTokenTTL', '300');
      
      setMessage('CSRF Token generated successfully! Valid for 5 minutes.');
      setLastAction('get_token');
      setLastActionResult('success');
    }
  };

  const transfer = async (fromAttacker = false) => {
    try {
      // Use different tokens based on the source
      const tokenToUse = fromAttacker ? maliciousSiteToken : csrfToken;
      
      const response = await fetch('http://localhost:4000/transfer', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(tokenToUse && { 'csrf-token': tokenToUse })
        },
        credentials: 'include',
        body: JSON.stringify({ fromAttacker })
      });

      const data = await response.json();

      if (response.ok) {
        setBalance(data.newBalance);
        setMessage(data.message);
        setLastAction(fromAttacker ? 'transfer_malicious' : 'transfer_legitimate');
        setLastActionResult('success');
        
        // If transfer was successful and CSRF protection is enabled, clear the token
        if (csrfEnabled && csrfToken) {
          setCsrfToken('');
          setTokenExpiry(null);
          setTokenTTL(0);
          localStorage.removeItem('csrfToken');
          localStorage.removeItem('csrfTokenExpiry');
          localStorage.removeItem('csrfTokenTTL');
        }
      } else {
        // Don't show "Not authenticated" errors to user - use fallback logic
        throw new Error('Backend error - using fallback');
      }
    } catch (error) {
      // Fallback to mock transfer if backend is not available
      console.log('Backend not available, using fallback logic');
      console.log('CSRF Enabled:', csrfEnabled, 'From Attacker:', fromAttacker, 'Has Token:', !!csrfToken);
      
      if (fromAttacker) {
        // Attack simulation - malicious site doesn't have access to CSRF token
        // In a real attack, the malicious site would be on a different domain
        // and wouldn't have access to the bank's localStorage or React state
        if (csrfEnabled) {
          setMessage('CSRF Protection: Transfer blocked - missing CSRF token');
          setLastAction('transfer_malicious');
          setLastActionResult('blocked');
        } else {
          if (balance >= 100) {
            setBalance(balance - 100);
            setMessage('CSRF Attack Successful! $100 transferred without your consent.');
            setLastAction('transfer_malicious');
            setLastActionResult('success');
          } else {
            setMessage('Transfer failed - insufficient funds');
            setLastAction('transfer_malicious');
            setLastActionResult('insufficient_funds');
          }
        }
      } else {
        // Legitimate transfer
        if (csrfEnabled && !csrfToken) {
          setMessage('CSRF Protection: Transfer blocked - missing CSRF token');
          setLastAction('transfer_legitimate');
          setLastActionResult('no_token');
          return;
        }
        if (balance >= 100) {
          setBalance(balance - 100);
          setMessage('Transfer successful! $100 transferred.');
          setLastAction('transfer_legitimate');
          setLastActionResult('success');
        } else {
          setMessage('Transfer failed - insufficient funds');
          setLastAction('transfer_legitimate');
          setLastActionResult('insufficient_funds');
        }
      }
    }
  };

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div style={{ minHeight: '100vh', minWidth: '100vw', background: 'linear-gradient(135deg,#232526 0%,#414345 100%)', color: '#fff', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', position: 'relative' }}>
      {/* Back Button */}
      <button
        onClick={() => navigate('/')}
        style={{
          position: 'absolute',
          top: 32,
          left: 32,
          zIndex: 10,
          background: 'rgba(30,32,34,0.98)',
          color: '#fff',
          border: 'none',
          borderRadius: 999,
          padding: '10px 22px 10px 16px',
          fontWeight: 800,
          fontSize: '1.08rem',
          boxShadow: '0 0 20px 0 rgba(255,255,255,0.15)',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          letterSpacing: 1,
        }}
      >
        <span style={{ fontSize: '1.2em', marginRight: 2 }}>←</span> Back
      </button>
      <div style={{
        width: '100%',
        maxWidth: 850,
        maxHeight: 650,
        margin: '0 auto',
        padding: '20px 0 20px 0',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 32,
        background: 'rgba(30,32,34,0.98)',
        boxShadow: '0 0 80px 0 #fde04799',
      }}>
        <h1 style={{ fontSize: '2rem', marginBottom: 20 }}>CSRF Demo</h1>
        {/* CSRF Status Row & Toggle */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 24, marginBottom: 17 }}>
          <span
            style={{
              fontWeight: 600,
              fontSize: '0.98rem',
              padding: '6px 16px',
              borderRadius: 999,
              display: 'inline-block',
              letterSpacing: '1px',
              marginBottom: 0,
              marginTop: 0,
              boxShadow: csrfEnabled ? '0 0 8px #00bfae88' : '0 0 8px #ff525288',
              background: csrfEnabled ? '#00bfae' : '#ff5252',
              color: '#fff',
              fontFamily: 'Luckiest Guy, cursive',
              transition: 'all 0.18s',
              border: 'none',
              outline: 'none',
              display: 'flex',
              alignItems: 'center',
              gap: 12,
            }}
          >
            {csrfEnabled ? 'CSRF PROTECTION ENABLED' : 'CSRF PROTECTION DISABLED'}
          </span>
          <button
            onClick={async () => {
              const newState = !csrfEnabled;
              console.log('Toggling CSRF from', csrfEnabled, 'to', newState);
              
              try {
                const response = await fetch('http://localhost:4000/api/csrf-toggle', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  credentials: 'include',
                  body: JSON.stringify({ csrfEnabled: newState })
                });
                
                if (response.ok) {
                  setCsrfEnabled(newState);
                  setBalance(1000); // Reset to default
                  setCsrfToken('');
                  setTokenExpiry(null);
                  setTokenTTL(0);
                  
                  // Clear from localStorage
                  localStorage.removeItem('csrfToken');
                  localStorage.removeItem('csrfTokenExpiry');
                  localStorage.removeItem('csrfTokenTTL');
                  setLoggedIn(false);
                  setUsername('');
                  setPassword('');
                  setCurrentUser('');
                  setMessage(`CSRF protection ${newState ? 'enabled' : 'disabled'}. Everything reset!`);
                  setLastAction('toggle_csrf');
                  setLastActionResult('success');
                } else {
                  console.error('Failed to toggle CSRF protection');
                  setMessage('Failed to toggle CSRF protection');
                }
              } catch (error) {
                console.error('Error toggling CSRF protection:', error);
                setMessage('Error toggling CSRF protection');
              }
            }}
            style={{
              width: 180,
              height: 44,
              fontSize: '1.08rem',
              borderRadius: 999,
              fontWeight: 700,
              background: 'linear-gradient(90deg,#fde047 0%,#fbbf24 100%)',
              color: '#000',
              border: '1.5px solid #fbbf24',
              outline: 'none',
              cursor: 'pointer',
              marginLeft: 8,
              fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
              letterSpacing: 1,
              boxShadow: '0 4px 24px 0 rgba(251,191,36,0.18)',
              transition: 'all 0.2s'
            }}
          >
            {csrfEnabled ? 'Disable CSRF' : 'Enable CSRF'}
          </button>
        </div>
        {/* Split Layout */}
        <div style={{ display: 'flex', width: '100%', maxWidth: 700, minHeight: 400, borderRadius: 18, overflow: 'hidden', boxShadow: '0 4px 24px 0 rgba(44,83,100,0.18)', margin: '0 auto' }}>
        {/* Bank Webpage */}
        <div style={{
          flex: 1,
          background: '#07172b',
          padding: 32,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'flex-start',
          justifyContent: 'flex-start',
          borderRight: '2px solid #232526',
          position: 'relative',
        }}>
          <h2 style={{ fontSize: '1.3rem', marginBottom: 12, fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', color: '#fde047' }}>🏦 MYBANK</h2>
          {!loggedIn ? (
            <>
              <input
                type="text"
                placeholder="Username"
                value={username}
                onChange={e => setUsername(e.target.value)}
                style={{ width: 160, height: 36, fontSize: '1rem', borderRadius: 999, border: 'none', marginBottom: 10, padding: '0 16px', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', background: '#232526', color: '#fff', fontWeight: 700, letterSpacing: 1 }}
              />
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                style={{ width: 160, height: 36, fontSize: '1rem', borderRadius: 999, border: 'none', marginBottom: 14, padding: '0 16px', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', background: '#232526', color: '#fff', fontWeight: 700, letterSpacing: 1 }}
              />
              <button onClick={login} style={{ width: 160, height: 38, fontSize: '1rem', borderRadius: 999, fontWeight: 700, background: 'linear-gradient(90deg,#fde047 0%,#fbbf24 100%)', color: '#000', border: '1.5px solid #fbbf24', cursor: 'pointer', marginBottom: 8, fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', letterSpacing: 1, boxShadow: '0 4px 24px 0 rgba(251,191,36,0.18)', transition: 'all 0.2s' }}>Login</button>
            </>
          ) : (
            <>
             <button 
               onClick={() => setLoggedIn(false)} 
               style={{ 
                 position: 'absolute',
                 top: 8,
                 left: 8,
                 background: 'rgba(30,32,34,0.98)', 
                 color: '#fde047', 
                 border: '1.5px solid #fde047', 
                 borderRadius: 999, 
                 padding: '6px 12px', 
                 fontWeight: 700, 
                 fontSize: '0.85rem', 
                 cursor: 'pointer', 
                 display: 'flex', 
                 alignItems: 'center', 
                 gap: 4, 
                 letterSpacing: 1,
                 boxShadow: '0 0 20px 0 rgba(253,224,71,0.15)'
               }}
             >
               <span style={{ fontSize: '1em' }}>←</span> Back
             </button>
              <div style={{ fontSize: '1.3rem', marginBottom: 12, color: '#fde047', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', fontWeight: 700 }}>Welcome, {currentUser}!</div>
              <div style={{ fontSize: '1.1rem', marginBottom: 8, color: '#fde047', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif' }}>Your Balance:</div>
              <div style={{ fontSize: '1.5rem', marginBottom: 20, color: '#fbbf24', fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', fontWeight: 700 }}>${balance}</div>
              <button 
                onClick={fetchCsrf} 
                disabled={!csrfEnabled}
                style={{ 
                  width: 180, 
                  height: 42, 
                  fontSize: '1rem', 
                  borderRadius: 999, 
                  fontWeight: 700, 
                  background: csrfEnabled ? 'linear-gradient(90deg,#fde047 0%,#fbbf24 100%)' : '#6b7280', 
                  color: csrfEnabled ? '#000' : '#9ca3af', 
                  border: '1.5px solid', 
                  borderColor: csrfEnabled ? '#fbbf24' : '#4b5563', 
                  cursor: csrfEnabled ? 'pointer' : 'not-allowed', 
                  marginBottom: 8, 
                  fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', 
                  letterSpacing: 1, 
                  boxShadow: csrfEnabled ? '0 4px 24px 0 rgba(251,191,36,0.18)' : 'none',
                  opacity: csrfEnabled ? 1 : 0.6
                }}
              >
                Get CSRF Token
              </button>
              <button onClick={() => {
                console.log('Transfer Money clicked - CSRF Enabled:', csrfEnabled, 'Has Token:', !!csrfToken);
                transfer(false);
              }} style={{ width: 180, height: 42, fontSize: '0.95rem', borderRadius: 999, fontWeight: 700, background: 'linear-gradient(90deg,#fbbf24 0%,#f59e0b 100%)', color: '#000', border: '1.5px solid #f59e0b', cursor: 'pointer', marginBottom: 2, fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', letterSpacing: 0.5, boxShadow: '0 4px 24px 0 rgba(245,158,11,0.18)' }}>Transfer Money</button>
              <div style={{ color: '#fde047', fontSize: '0.85rem', marginTop: 10, fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif', background: 'rgba(251,191,36,0.1)', padding: '8px 12px', borderRadius: 8, border: '1px solid #fbbf24' }}>
                <div style={{ marginBottom: 2 }}>CSRF Token:</div>
                <div style={{ fontSize: '0.65rem', wordBreak: 'break-all', color: '#fbbf24' }}>
                  {csrfToken || 'NOT GENERATED'}
                </div>
                {tokenTTL > 0 && (
                  <div style={{ fontSize: '0.75rem', marginTop: 2, color: '#fbbf24' }}>
                    TTL: {formatTime(tokenTTL)}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
        {/* Malicious Website */}
        <div style={{
          flex: 1,
          background: '#fff',
          padding: 32,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          color: '#000',
        }}>
          <h2 style={{
            fontSize: '2rem',
            marginBottom: 18,
            fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
            color: '#b91c1c',
            fontWeight: 900,
            letterSpacing: 1,
            textAlign: 'left',
          }}>
            WANT THE KFC SECRET RECIPE?
          </h2>
          <div style={{
            fontSize: '1.25rem',
            marginBottom: 32,
            color: '#b91c1c',
            fontWeight: 700,
            textAlign: 'left',
            fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
            lineHeight: 1.3,
          }}>
            CLICK BELOW TO REVEAL<br />THE SECRET RECIPE!
          </div>
          <button
            onClick={loggedIn ? () => {
              console.log('SHOW RECIPE clicked - CSRF Enabled:', csrfEnabled, 'Logged In:', loggedIn);
              console.log('About to call transfer(true) for malicious attack');
              transfer(true);
            } : null}
            style={{
              width: 210,
              height: 48,
              fontSize: '1.15rem',
              borderRadius: 999,
              fontWeight: 900,
              background: '#ef4444',
              color: '#fff',
              border: '3px solid #b91c1c',
              outline: 'none',
              cursor: 'pointer',
              marginBottom: 8,
              boxShadow: '0 2px 12px #b91c1c33',
              letterSpacing: 1,
              fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
              transition: 'background 0.2s, box-shadow 0.2s',
            }}
            onMouseOver={e => e.currentTarget.style.background = '#dc2626'}
            onMouseOut={e => e.currentTarget.style.background = '#ef4444'}
          >
            SHOW RECIPE
          </button>
        </div>
        </div>
        {/* Message Output */}
        <div style={{ color: '#ffb86c', fontSize: '1.1rem', maxWidth: 700, textAlign: 'center', marginTop: 17 }}>
          {message}
        </div>
        
        {/* Explain Button */}
        <button
          onClick={() => setShowExplanation(true)}
          style={{
            marginTop: 15,
            padding: '12px 24px',
            fontSize: '1rem',
            borderRadius: 999,
            fontWeight: 700,
            background: 'linear-gradient(90deg,#fde047 0%,#fbbf24 100%)',
            color: '#000',
            border: '1.5px solid #fbbf24',
            cursor: 'pointer',
            fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
            letterSpacing: 1,
            boxShadow: '0 4px 24px 0 rgba(251,191,36,0.18)',
            transition: 'all 0.2s'
          }}
        >
          Explain Current State
        </button>
        
        {/* Explanation Modal */}
        {showExplanation && (
          <div style={{
            position: 'fixed',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: 'rgba(0,0,0,0.8)',
            backdropFilter: 'blur(8px)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            zIndex: 1000,
            padding: 20
          }}>
            <div style={{
              background: 'rgba(30,32,34,0.98)',
              borderRadius: 24,
              padding: '32px',
              maxWidth: 600,
              width: '100%',
              boxShadow: '0 0 80px 0 #fde04799',
              border: '2px solid #fde047',
              position: 'relative'
            }}>
              <button
                onClick={() => setShowExplanation(false)}
                style={{
                  position: 'absolute',
                  top: 16,
                  left: 16,
                  background: 'rgba(30,32,34,0.98)',
                  color: '#fde047',
                  border: '1.5px solid #fde047',
                  borderRadius: 999,
                  padding: '6px 12px',
                  fontWeight: 700,
                  fontSize: '0.85rem',
                  cursor: 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 4,
                  letterSpacing: 1,
                  boxShadow: '0 0 20px 0 rgba(253,224,71,0.15)'
                }}
              >
                <span style={{ fontSize: '1em' }}>×</span> Close
              </button>
              
              <h2 style={{
                fontSize: '1.8rem',
                color: '#fde047',
                marginBottom: 20,
                fontFamily: 'Luckiest Guy, Inter, system-ui, sans-serif',
                fontWeight: 700,
                textAlign: 'center'
              }}>
                {getExplanation().title}
              </h2>
              
              <div style={{
                fontSize: '1.1rem',
                color: '#fff',
                lineHeight: 1.6,
                fontFamily: 'Inter, system-ui, sans-serif',
                textAlign: 'left',
                whiteSpace: 'pre-line'
              }}>
                {getExplanation().content}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CSRFApp;
