import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

// Add Google Fonts link for Inter
if (!document.getElementById('inter-font')) {
  const link = document.createElement('link');
  link.id = 'inter-font';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap';
  document.head.appendChild(link);
}

// Add Google Fonts link for Luckiest Guy
if (!document.getElementById('luckiest-guy-font')) {
  const link = document.createElement('link');
  link.id = 'luckiest-guy-font';
  link.rel = 'stylesheet';
  link.href = 'https://fonts.googleapis.com/css2?family=Luckiest+Guy&display=swap';
  document.head.appendChild(link);
}

function prettyPrintTable(data, level = 0) {
  if (!data || typeof data !== 'object') return String(data);
  const entries = Object.entries(data);
  return (
    <div style={{
      width: '100%',
      maxWidth: 480,
      margin: level === 0 ? '0 auto' : '0',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      paddingLeft: level > 0 ? 12 : 0,
      boxSizing: 'border-box',
    }}>
      {entries.map(([key, value]) => {
        const capKey = key.charAt(0).toUpperCase() + key.slice(1).replace(/([A-Z])/g, ' $1').trim();
        const isMessage = key.toLowerCase() === 'message';
        const accentColor = isMessage ? '#00e676' : '#ffb86c';
        const bgColor = level === 0 ? 'rgba(44,83,100,0.10)' : 'rgba(44,83,100,0.06)';
        return (
          <div key={key} style={{
            background: bgColor,
            borderRadius: 8,
            borderLeft: `4px solid ${accentColor}`,
            boxShadow: '0 1px 4px 0 rgba(44,83,100,0.08)',
            padding: '6px 8px 6px 8px',
            margin: 0,
            width: '100%',
            minWidth: 0,
            display: 'flex',
            flexDirection: 'column',
            gap: 3,
            position: 'relative',
            overflow: 'hidden',
          }}>
            <div style={{
              fontFamily: 'Luckiest Guy, cursive',
              fontWeight: 900,
              fontSize: '0.93rem',
              color: accentColor,
              textTransform: 'uppercase',
              letterSpacing: 0.7,
              marginBottom: 3,
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              background: 'rgba(255,255,255,0.04)',
              padding: '2px 7px',
              borderRadius: 6,
              width: 'fit-content',
              boxShadow: '0 1px 2px 0 rgba(44,83,100,0.06)',
            }}>
              <span style={{
                display: 'inline-block',
                width: 7,
                height: 7,
                borderRadius: 7,
                background: accentColor,
                marginRight: 3,
                boxShadow: isMessage ? '0 0 2px #00e67688' : '0 0 2px #ffb86c88',
              }}></span>
              {capKey}
            </div>
            <div style={{
              fontWeight: isMessage ? 700 : 500,
              color: isMessage ? '#00e676' : '#f1fa8c',
              fontSize: isMessage ? '0.93rem' : '0.89rem',
              display: Array.isArray(value) ? 'flex' : 'block',
              flexWrap: 'wrap',
              alignItems: 'center',
              gap: Array.isArray(value) ? 5 : 0,
              minHeight: 14,
              fontFamily: 'Fira Mono,Consolas,monospace',
              overflow: 'hidden',
              justifyContent: 'flex-start',
              marginTop: Array.isArray(value) ? 3 : 0,
            }}>
              {isMessage && typeof value === 'string' ? (
                <span>{value}</span>
              ) : Array.isArray(value) ? (
                value.map((v, i) => (
                  <span key={i} style={{
                    background: '#3b2f4a',
                    color: '#fff',
                    borderRadius: 999,
                    padding: '2px 8px',
                    marginRight: 3,
                    fontWeight: 700,
                    fontSize: '0.87rem',
                    marginBottom: 2,
                    display: 'inline-block',
                    boxShadow: '0 1px 2px #ffb86c33',
                    border: '1px solid #ffb86c',
                    whiteSpace: 'nowrap',
                    transition: 'box-shadow 0.2s',
                  }}>{v}</span>
                ))
              ) : typeof value === 'object' && value !== null ? (
                prettyPrintTable(value, level + 1)
              ) : (
                key.toLowerCase() === 'name' ? (
                  <span style={{ color: '#a78bfa', fontWeight: 700, background: 'none', border: 'none', whiteSpace: 'pre-line' }}>{String(value).trim()}</span>
                ) : (
                  <span style={{ color: isMessage ? '#00e676' : '#f1fa8c', whiteSpace: 'pre-line' }}>{String(value).trim()}</span>
                )
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function getExplanation({ corsEnabled, response }) {
  // Try to parse response as JSON
  let json = null;
  try {
    json = typeof response === 'string' ? JSON.parse(response) : response;
  } catch {}
  // CORS disabled and error
  if (!corsEnabled && response && response.toLowerCase().includes('cors')) {
    // Preflight explanation already handled above, so this is for API call
    if (response.toLowerCase().includes('post') || response.toLowerCase().includes('api call')) {
      return (
        <div>
          <span style={{ color: '#ff5252' }}>
            When one website tries to communicate with another website on a different origin (like a different domain or port), it's called a cross-origin request. If CORS is disabled, the other website might send a response.<br /><br />
            However, because the response doesn’t include the required CORS headers, the browser blocks your JavaScript from accessing the response for security reasons.<br /><br />
            This is done to prevent malicious websites from secretly reading data from another site’s server.<br /><br />
            So even though the request was sent and the server replied, the browser says:<br />
            <span style={{ color: '#fff', fontStyle: 'italic' }}>&ldquo;No CORS headers? Sorry, your JS can’t touch this.&rdquo;</span><br /><br />
            That’s why you see a CORS error in the browser, even though the API call technically reached the server and got a response.
          </span>
        </div>
      );
    }
    // Preflight explanation (leave as is)
    return (
      <div> 
        <span style={{ color: '#ff5252' }}>
          When a cross-origin request is made with special headers or methods, the browser first sends a preflight OPTIONS request asking the server: <br />
          <span style={{ color: '#fff', fontStyle: 'italic' }}>&lsquo;Am I allowed to do this?&rsquo;</span><br /><br />
          The server then checks who’s allowed to pass — by looking at the <span style={{color:'#fff'}}>Access-Control-Allow-Origin</span>, <span style={{color:'#fff'}}>Access-Control-Allow-Methods</span>, and <span style={{color:'#fff'}}>Access-Control-Allow-Headers</span> headers.<br /><br />
          If it finds none of them set, it responds to the browser saying: <br />
          <span style={{ color: '#fff', fontStyle: 'italic' }}>&lsquo;Nothing is allowed to pass.&rsquo;</span><br /><br />
          As a result, the browser blocks the actual request from being sent.
        </span>
      </div>
    );
  }
  // CORS enabled and preflight success
  if (corsEnabled && json && json.allowedMethods) {
    return (
      <div>
        <span style={{ color: '#00e676' }}>CORS is enabled on the backend. The preflight (OPTIONS) request succeeded, and the server responded with allowed methods and headers. This means the browser will allow the actual API request to proceed.</span>
      </div>
    );
  }
  // CORS enabled and API call success
  if (corsEnabled && json && json.message && !json.allowedMethods) {
    return (
      <div>
        <span style={{ color: '#00e676' }}>CORS is enabled on the backend. The API call succeeded, and you received a valid response from the server. The browser allowed this because the server sent the correct CORS headers.</span>
      </div>
    );
  }
  // CORS enabled but error
  if (corsEnabled && response && response.toLowerCase().includes('error')) {
    return (
      <div>
        <span style={{ color: '#ffb86c' }}>CORS is enabled, but there was an error unrelated to CORS (such as a network or server error). Check the error message for details.</span>
      </div>
    );
  }
  // Default
  return null;
}

function App() {
  const navigate = useNavigate();
  const [response, setResponse] = useState('');
  const [corsEnabled, setCorsEnabled] = useState(true);
  const [loadingCors, setLoadingCors] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);

  // Always fetch the latest CORS state on mount and after toggling
  const fetchCorsState = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/cors-state');
      const data = await res.json();
      setCorsEnabled(data.corsEnabled);
    } catch {
      setCorsEnabled(false);
    }
  };

  useEffect(() => {
    fetchCorsState();
  }, []);

  const toggleCors = async () => {
    setLoadingCors(true);
    setShowExplanation(false);
    setResponse('');
    try {
      const res = await fetch('http://localhost:4000/api/cors-toggle', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ corsEnabled: !corsEnabled })
      });
      const data = await res.json();
      setCorsEnabled(data.corsEnabled);
    } catch (err) {
      setResponse('❌ Toggle CORS error: ' + err.message);
    } finally {
      setLoadingCors(false);
      fetchCorsState();
    }
  };

  const callPreflight = async () => {
    setLoadingCors(true);
    try {
      const res = await fetch('http://localhost:4000/api/data', {
        method: 'OPTIONS',
        headers: {
          'Origin': 'http://localhost:5173',
          'Access-Control-Request-Method': 'POST',
          'Access-Control-Request-Headers': 'Content-Type, X-Custom-Break-CORS'
        }
      });
      if (res.status === 403) {
        setResponse('❌ There is nothing allowed to pass (CORS is fully disabled).');
        setLoadingCors(false);
        return;
      }
      let data;
      try {
        data = await res.json();
      } catch {
        setResponse('❌ There is nothing allowed to pass (CORS is fully disabled).');
        setLoadingCors(false);
        return;
      }
      if (
        (!data.allowedMethods || data.allowedMethods.length === 0) &&
        (!data.allowedHeaders || data.allowedHeaders.length === 0)
      ) {
        setResponse('❌ There is nothing allowed to pass (CORS is fully disabled).');
      } else {
        setResponse(JSON.stringify(data, null, 2));
      }
    } catch (err) {
      setResponse('❌ There is nothing allowed to pass (CORS is fully disabled).');
    }
    setLoadingCors(false);
  };

  const callBackend = async () => {
    try {
      const res = await fetch('http://localhost:4000/api/data', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Custom-Break-CORS': 'test-post'
        },
        body: JSON.stringify({ name: 'Ziad' })
      });
      if (!res.ok) {
        throw new Error('Server responded with status ' + res.status);
      }
      const data = await res.json();
      setResponse(JSON.stringify(data, null, 2));
    } catch (err) {
      setResponse('❌ POST error: ' + err.message + '\n(CORS may be disabled or blocked by browser)');
    }
  };

  // Handler for disabled button click (custom per button)
  const showCORSBlockedPreflight = () => {
    setResponse('❌ CORS is blocking the preflight request because it is disabled on the backend.');
  };
  const showCORSBlockedBackend = () => {
    setResponse('❌ CORS is blocking the backend API call because it is disabled on the backend.');
  };

  return (
    <div style={styles.bg}>
      {/* Back Button */}
      <button
        onClick={() => navigate('/')}
        style={{
          position: 'absolute',
          top: 32,
          left: 32,
          zIndex: 10,
          background: 'rgba(30,32,34,0.98)',
          color: '#fff',
          border: 'none',
          borderRadius: 999,
          padding: '10px 22px 10px 16px',
          fontWeight: 800,
          fontSize: '1.08rem',
          boxShadow: '0 0 20px 0 rgba(255,255,255,0.15)',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          gap: 8,
          letterSpacing: 1,
        }}
      >
        <span style={{ fontSize: '1.2em', marginRight: 2 }}>←</span> Back
      </button>
      <div style={styles.card}>
        <h1 style={styles.heading}>
          CORS & Preflight DEMO
        </h1>
        {/* Status and Toggle Row */}
        <div style={styles.statusToggleRow}>
          <span style={{
            ...styles.status,
            background: corsEnabled ? '#00bfae' : '#ff5252',
            color: '#fff',
            boxShadow: corsEnabled ? '0 0 8px #00bfae88' : '0 0 8px #ff525288'
          }}>
            {corsEnabled ? 'CORS ENABLED' : 'CORS DISABLED'}
          </span>
          <button
            className="gradient-btn"
            onClick={toggleCors}
            style={{
              ...styles.button,
              ...styles.pill,
              ...styles.gradientBtn,
              fontWeight: 700
            }}
            disabled={loadingCors}
          >
            {loadingCors ? 'Toggling...' : (corsEnabled ? 'Disable CORS' : 'Enable CORS')}
          </button>
        </div>
        {/* Divider */}
        <div style={styles.divider}></div>
        {/* API Action Buttons */}
        <div style={styles.apiButtonGroup}>
          <button
            className="gradient-btn"
            onClick={callPreflight}
            style={{ ...styles.button, ...styles.pill, ...styles.gradientBtn, fontWeight: 700 }}
            disabled={loadingCors}
          >
            Preflight
          </button>
          <button
            className="gradient-btn"
            onClick={corsEnabled && !loadingCors ? callBackend : showCORSBlockedBackend}
            style={{ ...styles.button, ...styles.pill, ...styles.gradientBtn, fontWeight: 700 }}
            disabled={loadingCors}
          >
            Call Backend API
          </button>
        </div>
        <pre style={styles.output}>
          {(() => {
            try {
              const json = typeof response === 'string' ? JSON.parse(response) : response;
              if (typeof json === 'object' && json !== null) {
                return prettyPrintTable(json);
              }
              return response || 'Click a button to test the API.';
            } catch {
              return response || 'Click a button to test the API.';
            }
          })()}
        </pre>
        <button
          className="gradient-btn"
          style={{ marginTop: 18, ...styles.gradientBtn, width: 220, height: 50, fontSize: '1.18rem', borderRadius: 999, fontWeight: 800, letterSpacing: '1px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          onClick={() => setShowExplanation((v) => !v)}
        >
          {showExplanation ? 'Hide Explanation' : 'Explain'}
        </button>
        {showExplanation && (
          <div style={{
            ...styles.output,
            marginTop: 10,
            color: '#fff',
            fontWeight: 500,
            fontSize: '0.95rem',
            lineHeight: 1.7,
            minHeight: 0,
            maxWidth: 520,
            marginLeft: 'auto',
            marginRight: 'auto',
            borderLeft: corsEnabled ? '5px solid #00e676' : '5px solid #ff5252',
            borderRight: 'none',
            borderTop: 'none',
            borderBottom: 'none',
            boxShadow: '0 2px 8px 0 rgba(44,83,100,0.10)',
            background: 'linear-gradient(120deg,#232526 0%,#2c2e33 100%)',
            overflowX: 'hidden',
            overflowY: 'auto',
            maxHeight: 145,
          }}>
            {getExplanation({ corsEnabled, response }) || <span>No explanation available for this state.</span>}
          </div>
        )}
      </div>
    </div>
  );
}

const styles = {
  bg: {
    minHeight: '100vh',
    minWidth: '100vw',
    height: '100vh',
    width: '100vw',
    background: 'linear-gradient(135deg,#232526 0%,#414345 100%)',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    fontFamily: 'Luckiest Guy, cursive',
    padding: 0,
    margin: 0,
    boxSizing: 'border-box',
    overflow: 'hidden',
  },
  card: {
    background: 'rgba(30,32,34,0.98)',
    borderRadius: 24,
    boxShadow: '0 0 80px 0 #1a237e99, 0 8px 32px 0 rgba(22, 211, 135, 0.37)',
    padding: '1px 20px 20px 20px',
    width: '100%',
    maxWidth: 600,
    minHeight: 400,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    margin: 0,
    boxSizing: 'border-box',
  },
  heading: {
    fontSize: '2.2rem',
    fontWeight: 700,
    marginBottom: 20,
    color: '#fff',
    letterSpacing: '-1px',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    gap: 10
  },
  icon: {
    fontSize: '2.2rem',
    marginRight: 6
  },
  statusRow: {
    marginBottom: 24,
    display: 'flex',
    justifyContent: 'center',
    width: '100%'
  },
  status: {
    fontWeight: 600,
    fontSize: '1.15rem',
    padding: '10px 22px',
    borderRadius: 999,
    display: 'inline-block',
    letterSpacing: '1px',
    marginBottom: 0,
    marginTop: 0,
    boxShadow: '0 2px 8px rgba(0,0,0,0.12)'
  },
  buttonGroup: {
    display: 'flex',
    gap: '18px',
    marginBottom: '28px',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: '100%'
  },
  button: {
    fontSize: '1.08rem',
    fontWeight: 600,
    padding: '13px 32px',
    border: 'none',
    outline: 'none',
    cursor: 'pointer',
    transition: 'all 0.18s',
    margin: 0,
    boxShadow: '0 2px 8px rgba(0,0,0,0.10)',
    marginBottom: 0,
    marginTop: 0,
    userSelect: 'none',
    letterSpacing: '0.5px',
  },
  pill: {
    borderRadius: 999,
  },
  output: {
    background: 'linear-gradient(120deg,#232526 0%,#2c2e33 100%)',
    color: '#e0e0e0',
    padding: '14px 10px',
    borderRadius: 16,
    width: '100%',
    maxWidth: 520,
    minHeight: 50,
    fontFamily: 'Fira Mono,Consolas,monospace',
    fontSize: '0.95rem',
    marginTop: 10,
    boxShadow: '0 4px 24px 0 rgba(44,83,100,0.18)',
    wordBreak: 'break-word',
    whiteSpace: 'pre-line',
    border: '1.5px solid #2c5364',
    textAlign: 'left',
    lineHeight: 1.6,
    overflowX: 'hidden',
    overflowY: 'auto',
    maxHeight: 145,
    minWidth: 0,
    boxSizing: 'border-box',
    scrollbarColor: '#2c5364 #232526',
    scrollbarWidth: 'thin',
    marginLeft: 'auto',
    marginRight: 'auto',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  footer: {
    color: '#bdbdbd',
    fontSize: '1rem',
    marginTop: 12,
    textAlign: 'center',
    opacity: 0.85
  },
  statusToggleRow: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 32,
    marginBottom: 18,
    marginTop: 8,
    width: '100%',
  },
  toggleBtn: {
    minWidth: 170,
    fontSize: '1.08rem',
    padding: '18px 0',
    boxShadow: '0 2px 8px rgba(0,0,0,0.10)',
  },
  divider: {
    width: '100%',
    height: 2,
    background: 'linear-gradient(90deg,#232526 0%,#414345 100%)',
    opacity: 0.18,
    borderRadius: 2,
    margin: '3px 0 16px 0',
    boxShadow: '0 1px 8px rgba(0,0,0,0.10)',
  },
  apiButtonGroup: {
    display: 'flex',
    flexDirection: 'row',
    gap: '32px',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: '12px',
    width: '100%',
  },
  apiBtn: {
    minWidth: 180,
    fontSize: '1.15rem',
    padding: '18px 0',
    borderRadius: 999,
    boxShadow: '0 2px 12px rgba(0,0,0,0.10)',
  },
  gradientBtn: {
    width: 220,
    height: 50,
    minWidth: 220,
    maxWidth: 220,
    fontSize: '1.18rem',
    padding: 0,
    borderRadius: 999,
    background: 'linear-gradient(90deg,#0f2027 0%,#2c5364 100%)',
    color: '#fff',
    border: '1.5px solid #2c5364',
    margin: 0,
    marginBottom: 0,
    marginTop: 0,
    userSelect: 'none',
    letterSpacing: '1px',
    fontWeight: 800,
    boxShadow: '0 4px 24px 0 rgba(44,83,100,0.18)',
    transition: 'all 0.18s cubic-bezier(.4,2,.6,1)',
    outline: 'none',
    position: 'relative',
    zIndex: 1,
    overflow: 'hidden',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    textAlign: 'center',
  },
};

export default App;
