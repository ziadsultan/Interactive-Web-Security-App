const express = require('express');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const app = express();

app.use(express.json());
app.use(cookieParser());

let corsEnabled = true;
let csrfEnabled = true;

// Enhanced session storage with tab tracking
const sessions = new Map();
const csrfTokens = new Map();
const tabSessions = new Map(); // Track sessions per tab

// Generate secure random token
const generateSecureToken = () => {
  return crypto.randomBytes(32).toString('hex');
};

// Generate tab-specific session ID
const generateTabSessionId = (baseSessionId, tabId) => {
  return crypto.createHash('sha256')
    .update(`${baseSessionId}-${tabId}-${Date.now()}`)
    .digest('hex');
};

// CORS configuration for all endpoints
app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:5173');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Custom-Break-CORS, csrf-token');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  
  // Handle preflight requests
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
    return;
  }
  next();
});

// Endpoint to get current CORS state
app.get('/api/cors-state', (req, res) => {
  res.json({ corsEnabled });
});

// Endpoint to toggle CORS state
app.post('/api/cors-toggle', (req, res) => {
  if (typeof req.body.corsEnabled === 'boolean') {
    corsEnabled = req.body.corsEnabled;
    res.json({ corsEnabled });
  } else {
    res.status(400).json({ error: 'corsEnabled (boolean) required' });
  }
});

// Endpoint to get current CSRF state
app.get('/api/csrf-state', (req, res) => {
  res.json({ csrfEnabled });
});

// Endpoint to toggle CSRF state
app.post('/api/csrf-toggle', (req, res) => {
  if (typeof req.body.csrfEnabled === 'boolean') {
    csrfEnabled = req.body.csrfEnabled;
    res.json({ csrfEnabled });
  } else {
    res.status(400).json({ error: 'csrfEnabled (boolean) required' });
  }
});

// Enhanced login with tab tracking
app.post('/login', (req, res) => {
  const { username, password, tabId } = req.body;
  
  // Validate credentials (simplified for demo)
  const validUsers = {
    'ziad': { password: '1021', balance: 1400, name: 'Ziad' },
    'abdelaal': { password: '1234', balance: 1700, name: 'Abdelaal' }
  };
  
  const user = validUsers[username.toLowerCase()];
  
  if (user && user.password === password) {
    const baseSessionId = generateSecureToken();
    const tabSessionId = generateTabSessionId(baseSessionId, tabId);
    
    // Store session data
    sessions.set(baseSessionId, { 
      username: user.name, 
      balance: user.balance,
      loginTime: Date.now()
    });
    
    // Track tab-specific session
    tabSessions.set(tabSessionId, {
      baseSessionId,
      tabId,
      createdAt: Date.now()
    });
    
    res.cookie('sessionId', baseSessionId, { 
      httpOnly: true, 
      secure: false, // Set to true in production with HTTPS
      sameSite: 'lax',
      maxAge: 30 * 60 * 1000 // 30 minutes
    });
    
    res.cookie('tabSessionId', tabSessionId, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 30 * 60 * 1000 // 30 minutes
    });
    
    res.json({ 
      success: true, 
      message: `Login successful! Welcome ${user.name}.`,
      balance: user.balance,
      tabSessionId
    });
  } else {
    res.status(401).json({ error: 'Invalid username or password.' });
  }
});

// Enhanced CSRF token generation with tab-specific features
app.get('/csrf-token', (req, res) => {
  const sessionId = req.cookies?.sessionId;
  const tabSessionId = req.cookies?.tabSessionId;
  
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  if (!tabSessionId || !tabSessions.has(tabSessionId)) {
    return res.status(401).json({ error: 'Invalid tab session' });
  }
  
  const session = sessions.get(sessionId);
  const tabSession = tabSessions.get(tabSessionId);
  
  // Generate CSRF token with tab-specific entropy
  const tokenEntropy = crypto.createHash('sha256')
    .update(`${sessionId}-${tabSessionId}-${Date.now()}-${Math.random()}`)
    .digest('hex');
  
  const csrfToken = crypto.createHash('sha256')
    .update(`${tokenEntropy}-${session.username}-${tabSession.tabId}`)
    .digest('hex')
    .substring(0, 32); // Truncate to 32 chars for readability
  
  const expiresAt = Date.now() + (5 * 60 * 1000); // 5 minutes
  
  // Store token with enhanced metadata
  csrfTokens.set(csrfToken, { 
    sessionId, 
    tabSessionId,
    tabId: tabSession.tabId,
    username: session.username,
    expiresAt,
    createdAt: Date.now()
  });
  
  res.json({ 
    csrfToken,
    expiresAt,
    ttl: 300, // 5 minutes in seconds
    tabId: tabSession.tabId
  });
});

// Enhanced transfer with comprehensive CSRF validation
app.post('/transfer', (req, res) => {
  const sessionId = req.cookies?.sessionId;
  const tabSessionId = req.cookies?.tabSessionId;
  const csrfToken = req.headers['csrf-token'];
  const { fromAttacker } = req.body;
  
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  if (!tabSessionId || !tabSessions.has(tabSessionId)) {
    return res.status(401).json({ error: 'Invalid tab session' });
  }
  
  const session = sessions.get(sessionId);
  const tabSession = tabSessions.get(tabSessionId);
  
  // Check CSRF protection
  if (csrfEnabled) {
    if (!csrfToken) {
      return res.status(403).json({ 
        error: 'CSRF token required',
        message: 'CSRF Protection: Transfer blocked - missing CSRF token'
      });
    }
    
    const tokenData = csrfTokens.get(csrfToken);
    if (!tokenData) {
      return res.status(403).json({ 
        error: 'Invalid CSRF token',
        message: 'CSRF Protection: Transfer blocked - invalid CSRF token'
      });
    }
    
    // Validate token belongs to this session and tab
    if (tokenData.sessionId !== sessionId || tokenData.tabSessionId !== tabSessionId) {
      return res.status(403).json({ 
        error: 'CSRF token mismatch',
        message: 'CSRF Protection: Transfer blocked - token session/tab mismatch'
      });
    }
    
    if (Date.now() > tokenData.expiresAt) {
      csrfTokens.delete(csrfToken);
      return res.status(403).json({ 
        error: 'CSRF token expired',
        message: 'CSRF Protection: Transfer blocked - token expired'
      });
    }
    
    // Valid token - consume it
    csrfTokens.delete(csrfToken);
  } else {
    // CSRF protection is disabled - allow transfer without token
    // This simulates a vulnerable application
  }
  
  // Perform transfer
  if (session.balance >= 100) {
    session.balance -= 100;
    
    const message = fromAttacker 
      ? 'CSRF Attack Successful! $100 transferred without your consent.'
      : 'Transfer successful! $100 transferred.';
    
    res.json({ 
      success: true, 
      message,
      newBalance: session.balance
    });
  } else {
    res.status(400).json({ 
      error: 'Insufficient funds',
      message: 'Transfer failed - insufficient funds'
    });
  }
});

// Get current session info
app.get('/session-info', (req, res) => {
  const sessionId = req.cookies?.sessionId;
  const tabSessionId = req.cookies?.tabSessionId;
  
  if (!sessionId || !sessions.has(sessionId)) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  
  const session = sessions.get(sessionId);
  const tabSession = tabSessions.get(tabSessionId);
  
  res.json({
    username: session.username,
    balance: session.balance,
    tabId: tabSession?.tabId,
    loginTime: session.loginTime
  });
});

// Cleanup expired tokens and sessions every minute
setInterval(() => {
  const now = Date.now();
  
  // Clean expired CSRF tokens
  for (const [token, data] of csrfTokens.entries()) {
    if (now > data.expiresAt) {
      csrfTokens.delete(token);
    }
  }
  
  // Clean expired tab sessions (30 minutes)
  for (const [tabSessionId, data] of tabSessions.entries()) {
    if (now - data.createdAt > 30 * 60 * 1000) {
      tabSessions.delete(tabSessionId);
    }
  }
  
  // Clean expired main sessions (30 minutes)
  for (const [sessionId, data] of sessions.entries()) {
    if (now - data.loginTime > 30 * 60 * 1000) {
      sessions.delete(sessionId);
    }
  }
}, 60000);

// Block /api/data if CORS is disabled, and do NOT send CORS headers
app.use('/api/data', (req, res, next) => {
  if (!corsEnabled) {
    // If preflight (OPTIONS), block with 403 and no CORS headers
    if (req.method === 'OPTIONS') {
      return res.status(403).json({ error: 'CORS is disabled by server toggle.' });
    }
    // For all other methods, block with 403 and no CORS headers
    return res.status(403).json({ error: 'CORS is disabled by server toggle.' });
  }
  // If CORS is enabled, set headers
  res.setHeader('Access-Control-Allow-Origin', 'http://localhost:5173');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Custom-Break-CORS, csrf-token');
  res.setHeader('Access-Control-Allow-Credentials', 'true');
  next();
});

// Custom Preflight Response (only runs if CORS is enabled)
app.options('/api/data', (req, res) => {
  res.status(200).json({
    message: 'Preflight successful ✅',
    allowedMethods: ['GET', 'POST', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'X-Custom-Break-CORS', 'csrf-token']
  });
});

app.get('/api/data', (req, res) => {
  res.json({ message: 'GET: Hello from backend!' });
});

app.post('/api/data', (req, res) => {
  res.json({ message: 'POST received!', data: req.body });
});

app.listen(4000, () => {
  console.log('Backend API running at http://localhost:4000');
});
